webpackHotUpdate(0,{

/***/ "./node_modules/css-loader/index.js?{\"importLoaders\":1}!./node_modules/postcss-loader/lib/index.js?{\"ident\":\"postcss\",\"plugins\":[null,null]}!./src/components/App/App.css":
/* no static exports found */
/* all exports used */
/*!****************************************************************************************************************************************!*\
  !*** ./~/css-loader?{"importLoaders":1}!./~/postcss-loader/lib?{"ident":"postcss","plugins":[null,null]}!./src/components/App/index.css ***!
  \****************************************************************************************************************************************/
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../~/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(undefined);
// imports


// module
exports.push([module.i, "body {\n  background: #000000 url(" + __webpack_require__(/*! ./wood.jpg */ "./src/components/App/wood.jpg") + ");\n}\n\n.App {\n  text-align: center;\n}\n\n.App-logo {\n  -webkit-animation: App-logo-spin infinite 20s linear;\n          animation: App-logo-spin infinite 20s linear;\n  height: 50px;\n  background: #212121 url(" + __webpack_require__(/*! ./logo.png */ "./src/components/App/logo.png") + ") no-repeat right top;\n  background-size: 80px;\n}\n\n.App-header {\n  height: 150px;\n  padding: 20px;\n  color: white;\n}", ""]);

// exports


/***/ })

})
//# sourceMappingURL=0.872619d879f4f152fd28.hot-update.js.map