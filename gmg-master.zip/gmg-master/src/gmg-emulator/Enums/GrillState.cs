﻿namespace Gmg.Emulator.Enums
{
    public enum GrillState
    {
        OFF = 0,
        ON = 1,
        FAN = 2,
        REMAIN =3
    }
}