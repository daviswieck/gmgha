﻿namespace Gmg.Emulator.Responses
{
    public interface IResponse
    {
        byte[] ToBytes();
    }
}