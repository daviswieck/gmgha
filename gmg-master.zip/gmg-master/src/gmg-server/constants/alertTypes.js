module.exports = {
    targetFoodTempReached: 'targetFoodTempReached',
    targetGrillTempReached: 'targetGrillTempReached',
    unusualGrillTempDeviation: 'unusualGrillTempDeviation',
    unusualFoodTempDeviation: 'unusualFoodTempDeviation',
    lowPelletAlarmActive: 'lowPelletAlarmActive'
}