module.exports = Object.freeze({
    port: 8080,
    host: '255.255.255.255',
    tries: 5,
    retryMs: 2000
})